
# legion5 : fox on the run

[https://oblerion.itch.io/legion5-fox-on-the-run](legion5_for)
## Run game
- window : start egba.exe
- linux : ./egba
- mac : wine egba.exe


## Story:

In the year 3022, 
You play the role of a Spectre SyncCo pilot tasked with checking out unknown low-frequency signals coming from an alternate reality,
First, your lose your way.
Second, low level blaster ammo.
And it's your last rocket. Run
## Control:

- Arrow for move
- X for fire

## 2d engine:

[https://oblerion.itch.io/gba-engine](egba_engine)
## Author:

- code : oblerion
- drawing : oblerion
