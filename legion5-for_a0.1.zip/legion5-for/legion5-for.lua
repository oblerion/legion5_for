local version = "a0.1"
local screen_w = 960
local screen_h = 720

local id_ship = -1--rsave_numb(0)
local legion5_scene = 0

function legion5_title()
	-- code run 60/seconds
	cls(19)
	text("Legion5 : fox on the run",(screen_w/2)-260,30+(screen_h/4),1,45)
	text("press up",(screen_w/2)-35,500,1,25)

	spr(id_ship*3,(screen_w/2)-((6*16)/2),300,8)

	text("powered by egba engine",730,690,1,18)
	text("ver "..version.." by magnus oblerion",20,690,1,18)

	if btnp(2) then
		if id_ship == 0 then
			id_ship=2
		else
			id_ship = id_ship-1
		end
	end
	if btnp(3) then
		if id_ship == 2 then
			id_ship=0
		else
			id_ship = id_ship+1
		end
	end

	if	btnp(0) then
		wsave_numb(0,id_ship)
		legion5_scene=1
	end 
end

function legion5_signal_draw(px,py,dt)
  local ldt = dt
  local h=0.1+ldt*10 --x offset
  local b=1.2 -- frequ
  local yw = 5 -- y size
  for ly=0,50 do
    for lx=0,50 do
      local llx =px+lx*10
      local lly =py+(yw*math.sin((lx-h)/b))
      rect(llx,lly,10,10,1)
    end
  end
  
end
local gtime=0;
function legion5_game()
	cls(19)
	text("signal" ,50,100,1,25)
  text("type   : unknow" ,50,130,1,25)
  text("streng : weak" ,50,160,1,25)
  text("cord   : E09XZZ 0JDA5E 5ZF14A",50,190,1,25)
  legion5_signal_draw(45,245,gtime)
  gtime = gtime+1/60
end

function EGBA()
	if id_ship==-1 then
		id_ship=rsave_numb(0)
	end

	if legion5_scene==0 then
		legion5_title()
	elseif legion5_scene==1 then
		legion5_game()
	end
end
